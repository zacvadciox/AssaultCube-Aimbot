#include "arac.h"

float uzaklik(float xben, float yben, float zben, float xdusman, float ydusman, float zdusman)
{
	return sqrt((xben - xdusman) * (xben - xdusman) + (yben - ydusman) * (yben - ydusman) + (zben - zdusman) * (zben - zdusman));
}
typedef struct
{
	float x, y;
}Vec2;

Vec2 acihesapla(float benx,float beny,float benz,float dusmanx,float dusmany,float dusmanz,float mesafe)
{
	Vec2 angle;
	angle.x = -atan2f(dusmanx-benx, dusmany-beny) /pi * 180.0f + 180.0f;
	angle.y = asinf((dusmanz-benz) / mesafe) * 180.0f / pi;
	return angle;
}

int yakindusman(float _mesafe[], int _sayi)
{
	float temp;
	temp = _mesafe[1];
	int sayac=1;
	for (int i = 2; i < _sayi; i++)
	{
		if (_mesafe[i] < temp)
		{
			temp = _mesafe[i];
			sayac=i;
		}
	}
	return sayac;
}



void baslat()
{
	AllocConsole();
	freopen_s(&pFile, "CONOUT$", "w", stdout);
	DWORD ac_client_adres = (DWORD)GetModuleHandle(L"ac_client.exe");
	DWORD localplayerindex = ac_client_adres + localplayerbase;
	DWORD entityindex = (ac_client_adres + entitybase);
	DWORD* entitiylist = (DWORD*)entityindex;
	float benx, beny, benz, dusmanx, dusmany, dusmanz,mesafe[32];
	int can;
	int sayi;
	int yakinolan;
	Vec2 aci;
	float *_farex, *_farey;
	while (true)
	{
		sayi = *(int*)(ac_client_adres + oyuncusayi);
		for (int i = 1; i < sayi; i++)
		{
				can = *(int*)offsetadres(*entitiylist + i * 4, offsetcan, 1);
				if ((can > 0)&(can <=100))
				{
					benx = *(float*)offsetadres(localplayerindex, offsetx, 1);
					beny = *(float*)offsetadres(localplayerindex, offsety, 1);
					benz = *(float*)offsetadres(localplayerindex, offsetz, 1);
					dusmanx = *(float*)offsetadres(*entitiylist + i * 4, offsetx, 1);
					dusmany = *(float*)offsetadres(*entitiylist + i * 4, offsety, 1);
					dusmanz = *(float*)offsetadres(*entitiylist + i * 4, offsetz, 1);
					mesafe[i] = uzaklik(benx, beny, benz, dusmanx, dusmany, dusmanz);
				}
				else
				{
					mesafe[i] = max;
				}
				Sleep(1);
		}
		yakinolan = yakindusman(mesafe, sayi);
		dusmanx = *(float*)offsetadres(*entitiylist + (yakinolan) * 4, offsetx, 1);
		dusmany = *(float*)offsetadres(*entitiylist + (yakinolan) * 4, offsety, 1);
		dusmanz = *(float*)offsetadres(*entitiylist + (yakinolan) * 4, offsetz, 1);
		aci = acihesapla(benx, beny, benz, dusmanx, dusmany, dusmanz, mesafe[yakinolan]);
		_farex = (float*)offsetadres(localplayerindex, farex, 1);
		_farey = (float*)offsetadres(localplayerindex, farey, 1);
		if (GetAsyncKeyState(VK_LBUTTON))
		{
			*_farex = aci.x;
			*_farey = aci.y;
		}
		Sleep(1);
	}

}

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)baslat, hModule, 0, 0);
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}