#include <windows.h>
#include <cmath>
#include <iostream>
#define pi 3.1415
#define max     3.40282347E+38F
FILE* pFile = nullptr;
using namespace std;

DWORD offsetcan[1] = { 0xEC };
DWORD offsetx[1] = { 0x28 };
DWORD offsety[1] = { 0x2C };
DWORD offsetz[1] = { 0x30 };
DWORD farex[1] = { 0x34 };
DWORD farey[1] = { 0x38 };
DWORD entitybase = 0x00187C10;
DWORD localplayerbase = 0x00187C0C;
DWORD oyuncusayi = 0x187C18;
DWORD offsetadres(DWORD base, DWORD off[], int lvl)
{
	base = *(DWORD*)base;
	for (int i = 0; i < lvl; i++) {
		base += off[i];
		if (i < lvl - 1)
		{
			base = *(DWORD*)base;
		}
	}
	return base;
}
